// объект для манипуляции с данными формы добавления
let addFormData = new FormData(document.forms['add-form']);
// объект для манипуляции с данными формы изменения
let editFormData = new FormData(document.forms['edit-form']);
// объект для манипуляции с данными формы удаления
let deleteFormData = new FormData(document.forms['delete-form']);
// массив для пактеного удаления
let deleteFormDataRows = [];

// коллбэк на событие закрытия диалога
function addDialogCloseCallback() {
    // выбрать блок по id=dialog-add
    let dialogBlock = document.getElementById('dialog-add');

    // удалить у dialogBlock класс show и добавить класс hide
    dialogBlock.classList.remove('show');
    dialogBlock.classList.add('hide');
}

// коллбэк на событие закрытия диалога
function editDialogCloseCallback() {
    // выбрать блок по id=dialog-edit
    let dialogBlock = document.getElementById('dialog-edit');

    // удалить у dialogBlock класс show и добавить класс hide
    dialogBlock.classList.remove('show');
    dialogBlock.classList.add('hide');
}

// коллбэк на событие закрытия диалога
function deleteDialogCloseCallback() {
    // выбрать блок по id=dialog-delete
    let dialogBlock = document.getElementById('dialog-delete');

    // удалить у dialogBlock класс show и добавить класс hide
    dialogBlock.classList.remove('show');
    dialogBlock.classList.add('hide');
}

// коллбэк на событие открытия диалога
function deleteBatchDialogOpenCallback() {
	// выбрать блок по id=dialog-add
	let dialogBlock = document.getElementById('dialog-batch-delete');
	dialogBlock.classList.remove('hide');
	dialogBlock.classList.add('show');
}

// коллбэк на событие закрытия пакетного диалога
function deleteBatchDialogCloseCallback() {
    // выбрать блок по id=dialog-delete
    let dialogBlock = document.getElementById('dialog-batch-delete');

    // удалить у dialogBlock класс show и добавить класс hide
    dialogBlock.classList.remove('show');
    dialogBlock.classList.add('hide');
}

// функция-коллбэк. Вызывается при наступлении события отправки формы добавления
function addFormOnSubmit(evt) {
    // здесь evt -- это есть событие (submit)
    evt.preventDefault(); // отмена умолчального поведения формы (асинхронная отправка)

    // получаем текущее состояние формы
    let currentStateForm = new FormData(document.forms['add-form']);

    // устанавливаем значения у глобального объекта состояния формы
    addFormData.set('surname', currentStateForm.get('surname'));
    addFormData.set('name', currentStateForm.get('name'));
    addFormData.set('second-name', currentStateForm.get('second-name'));

    // проверяем
    // console.log('surname: ', addFormData.get('surname'));
    // console.log('name: ', addFormData.get('name'));
    // console.log('second-name: ', addFormData.get('second-name'));

    let catalogEntityData = JSON.stringify({
        "Description": addFormData.get('surname') + ' ' + addFormData.get('name') + ' ' + addFormData.get('second-name')
    });

    let catalogEntity = 'Catalog_ФизическиеЛица';

    function catalogEntityCreateCallback(otvet) {
        let data = JSON.parse(otvet);
        let refKey = data['Ref_Key'];

        // console.log('Ref_Key физического лица', refKey);

        // добавление документа
        let createData = JSON.stringify({
            "Имя": addFormData.get('name'),
            "Отчество": addFormData.get('second-name'),
            "Фамилия": addFormData.get('surname'),
            "Date": "2000-06-12T11:00:01",
            "СерияДокументаУдостоверяющегоЛичность": "1111",
            "НомерДокументаУдостоверяющегоЛичность": "2222",
            "КемВыданДокументУдостоверяющийЛичность": "ОВД 123456788",
            "ДатаВыдачиДокументаУдостоверяющегоЛичность": "2014-09-30T00:00:00",
            "ФизЛицо_Key": refKey,
            "КонтактнаяИнформация": [
                {
                    "Ref_Key": "94fa505c-e358-11e9-bab6-c33152fd611f",
                    "LineNumber": "1",
                    "Тип": "Телефон",
                    "Вид_Key": "b6807ccb-0a9b-4a02-9ce9-7934ca359b32",
                    "Представление": "123456",
                    "ЗначенияПолей": "<КонтактнаяИнформация xmlns=\"http://www.v8.1c.ru/ssl/contactinfo\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" Представление=\"123456\"><Комментарий/><Состав xsi:type=\"НомерТелефона\"/></КонтактнаяИнформация>",
                    "Страна": "",
                    "Регион": "",
                    "Район": "",
                    "Город": "",
                    "АдресЭП": "",
                    "ДоменноеИмяСервера": "",
                    "НомерТелефона": "",
                    "НомерТелефонаБезКодов": "",
                    "Комментарий": ""
                }
            ]
        });

        function createCallback(otvet) {
            let data = JSON.parse(otvet);

            if (data['Ref_Key'].length) {
                updateTable();
                addDialogCloseCallback();
            } else {
                alert('Что-то пошло не так!');
            }
        }

        odataCreate(h, e, createData, createCallback);

    }

    odataCreate(h, catalogEntity, catalogEntityData, catalogEntityCreateCallback);

}

// отобрать форму на дереве DOM
let addForm = document.getElementById('add-form');
addForm.addEventListener('submit', addFormOnSubmit);


// функция-коллбэк. Вызывается при наступлении события отправки формы добавления
function editFormOnSubmit(evt) {
    // здесь evt -- это есть событие (submit)
    evt.preventDefault(); // отмена умолчального поведения формы (асинхронная отправка)

    // получаем текущее состояние формы
    let currentStateForm = new FormData(document.forms['edit-form']);

    // устанавливаем значения у глобального объекта состояния формы
    editFormData.set('surname', currentStateForm.get('surname'));
    editFormData.set('name', currentStateForm.get('name'));
    editFormData.set('second-name', currentStateForm.get('second-name'));

    // проверяем
    console.log('id: ', editFormData.get('id'));
    console.log('surname: ', editFormData.get('surname'));
    console.log('name: ', editFormData.get('name'));
    console.log('second-name: ', editFormData.get('second-name'));
}

// отобрать форму на дереве DOM
let editForm = document.getElementById('edit-form');
editForm.addEventListener('submit', editFormOnSubmit);


// функция-коллбэк. Вызывается при наступлении события отправки формы добавления
function deleteFormOnSubmit(evt) {
    // здесь evt -- это есть событие (submit)
    evt.preventDefault(); // отмена умолчального поведения формы (асинхронная отправка)

    // проверяем
    console.log('id: ', deleteFormData.get('id'));

    let data = {
        'Ref_Key': deleteFormData.get('id')
    };

    function odataDeleteCallback() {
        updateTable();
        deleteDialogCloseCallback();
    }

    odataDelete(h, e, data, odataDeleteCallback);
}

// отобрать форму на дереве DOM
let deleteForm = document.getElementById('delete-form');
deleteForm.addEventListener('submit', deleteFormOnSubmit);


function initDialogsBehavior() {

    /* диалог добавления -- начало */

	// коллбэк на событие открытия диалога
    function addDialogOpenCallback() {
        // выбрать блок по id=dialog-add
        let dialogBlock = document.getElementById('dialog-add');

        // берём элементы дерева DOM с формой для очистки
        let currentForm = document.forms['add-form'];

        // выбираем дочерние элементы формы
        var childs = currentForm.children;

        // перебираем дочерние элементы формы в цикле
        for (i = 0; i < childs.length; i++) {
            // текущий элемент в итерации цикла
            let currentChild = childs[i];

            // эсли это тег input и это не кнопка отправки форма (т.е. type не равен submit)
            if ('INPUT' === currentChild.tagName && currentChild.getAttribute('type') !== 'submit') {
                // то значение приравниваем к пустой строке
                currentChild.value = '';
            }
        }

        // удалить у dialogBlock класс hide и добавить класс show
        dialogBlock.classList.remove('hide');
        dialogBlock.classList.add('show');
    }

    let btnAddOpenSelector = document.getElementById('btn-add-open');
    btnAddOpenSelector.addEventListener('click', addDialogOpenCallback);

    let btnAddCloseSelector = document.getElementById('btn-add-close');
    btnAddCloseSelector.addEventListener('click', addDialogCloseCallback);


    /* диалог добавления -- конец */


    /* диалог изменения -- начало */

	// коллбэк на событие открытия диалога
    function editDialogOpenCallback(e) {

        // читаем значение свойства id тыкнутой кнопки
        let clickedBtnPropIdVal = e.target.getAttribute('id');

        // инициализировали значение поля формы с именем id в значение clickedBtnPropIdVal
        editFormData.set('id', clickedBtnPropIdVal);

        // выбрать блок по id=dialog-edit
        let dialogBlock = document.getElementById('dialog-edit');

        // удалить у dialogBlock класс hide и добавить класс show
        dialogBlock.classList.remove('hide');
        dialogBlock.classList.add('show');
    }


    let btnEditOpenSelectors = document.getElementsByClassName('btn-edit-open');
    // проходим в цикле по всем элементам checkboxes
    for (var i = 0; i < btnEditOpenSelectors.length; i++) {
        let btnEditOpenSelector = btnEditOpenSelectors[i];
        btnEditOpenSelector.addEventListener('click', editDialogOpenCallback);
    }

    let btnEditCloseSelector = document.getElementById('btn-edit-close');
    btnEditCloseSelector.addEventListener('click', editDialogCloseCallback);

    /* диалог изменения -- конец */


    /* диалог удаления -- начало */

	// коллбэк на событие открытия диалога
    function deleteDialogOpenCallback(ev) {

        // читаем значение свойства id тыкнутой кнопки
        let clickedBtnPropIdVal = ev.target.getAttribute('id');
        // инициализировали значение поля формы с именем id в значение clickedBtnPropIdVal
        deleteFormData.set('id', clickedBtnPropIdVal);

        function odataRetrieveCallback(otvet) {
            let data = JSON.parse(otvet);

            // for edit!!!
            // deleteFormData.set('', data['Фамилия']);
            // deleteFormData.set('', data['Имя']);
            // deleteFormData.set('', data['Отчество']);

            let deleteDialogText = [
                '"',
                data['Фамилия'],
                ' ',
                data['Имя'],
                ' ',
                data['Отчество'],
                '"'
            ].join('');

            // v1
            // let deleteDialogTextElement = document.getElementById('delete-dialog-text');
            // deleteDialogTextElement.innerHTML = deleteDialogText;

            // v2
            document.getElementById('delete-dialog-text').innerHTML = [
                '"',
                data['Фамилия'],
                ' ',
                data['Имя'],
                ' ',
                data['Отчество'],
                '"'
            ].join('');

            // выбрать блок по id=dialog-delete
            let dialogBlock = document.getElementById('dialog-delete');

            // удалить у dialogBlock класс hide и добавить класс show
            dialogBlock.classList.remove('hide');
            dialogBlock.classList.add('show');

        }

        odataRetrieve(h, 'GET', e, odataRetrieveCallback, clickedBtnPropIdVal);
    }

    let btnDeleteOpenSelectors = document.getElementsByClassName('btn-delete-open');

	// проходим в цикле по всем элементам checkboxes
    for (var i = 0; i < btnDeleteOpenSelectors.length; i++) {
        let btnDeleteOpenSelector = btnDeleteOpenSelectors[i];
        btnDeleteOpenSelector.addEventListener('click', deleteDialogOpenCallback);
    }

    let btnDeleteCloseSelector = document.getElementById('btn-delete-close');
    btnDeleteCloseSelector.addEventListener('click', deleteDialogCloseCallback);

    /* диалог удаления -- конец */



	/* диалог пакетного удаления -- начало */

	let btnDeleteBatchDialogCloseSelector = document.getElementById('dialog-batch-delete-close');
	btnDeleteBatchDialogCloseSelector.addEventListener('click', deleteBatchDialogCloseCallback);


	/* диалог пакетного удаления -- конец */


}