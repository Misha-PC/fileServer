
function request(backendHost, method, entity, cb, params) {
    // backendHost: http://172.16.161.103/app/odata/standard.odata
    // method: GET, POST, PUT, PATCH, DELETE
    // entity: объект базы данных 1с (Document_АнкетаАбитуриента, Catalog_ФизическиеЛица и т.д...)
    // params: массив параметров. Например ['$format=json', '$select=Фамилия,Имя,Отчество,Ref_Key', '$top=5', '$skip=0']
    // создаём массив для работы с параметрами запроса
    let queryParams, queryParamsString;

    // если параметры отсутствуют то хотябы добавляем параметр для работы в формате json
    if(undefined === params){
        queryParams = [];
        queryParams.push('$format=json');
    } else {
        queryParams = params;
        // также, при наличии параметров, проверяем есть ли режим работы в формате json и если его нет, то добавляем
        if (queryParams.indexOf('$format=json') === -1){
            queryParams.push('$format=json');
        }
    }

    queryParamsString = queryParams.join('&');

    var data = null;

    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true; // запрашивать базовую аутентификацию стандартными средствами браузера

    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === 4) {
            cb(this.responseText);
            //console.log(this.responseText);
        }
    });

    xhr.open(method, backendHost + "/" + entity + "?" + queryParamsString);

    xhr.send(data);
    

}

function requestCount(backendHost, method, entity, cb) {
    // backendHost: http://172.16.161.103/app/odata/standard.odata
    // method: GET, POST, PUT, PATCH, DELETE
    // entity: объект базы данных 1с (Document_АнкетаАбитуриента, Catalog_ФизическиеЛица и т.д...)
    // создаём массив для работы с параметрами запроса
    let queryParams=[], queryParamsString;

    // если параметры отсутствуют то хотябы добавляем параметр для работы в формате json
    queryParams.push('$format=json');
    queryParamsString = queryParams.join('&');

    var data = null;

    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true; // запрашивать базовую аутентификацию стандартными средствами браузера

    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === 4) {
            cb(this.responseText);
            //console.log(this.responseText);
        }
    });

    xhr.open(method, backendHost + "/" + entity + "/$count" + "?" + queryParamsString);

    xhr.send(data);

}

// CRUD

function odataCreate(backendHost, entity, data, cb) {
    // backendHost: http://172.16.161.103/app/odata/standard.odata
    // entity: объект базы данных 1с (Document_АнкетаАбитуриента, Catalog_ФизическиеЛица и т.д...)
    // создаём массив для работы с параметрами запроса

    let method = 'POST';
    let queryParams=[], queryParamsString;

    // если параметры отсутствуют то хотябы добавляем параметр для работы в формате json
    queryParams.push('$format=json');
    queryParamsString = queryParams.join('&');

    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true; // запрашивать базовую аутентификацию стандартными средствами браузера

    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === 4) {
            cb(this.responseText);
        }
    });

    xhr.open(method, backendHost + "/" + entity + "?" + queryParamsString);
    xhr.send(data);
}

function odataRetrieve(backendHost, method, entity, cb, refKey) {
    // backendHost: http://172.16.161.103/app/odata/standard.odata
    // method: GET, POST, PUT, PATCH, DELETE
    // entity: объект базы данных 1с (Document_АнкетаАбитуриента, Catalog_ФизическиеЛица и т.д...)
    let queryParamsString = '$format=json';
    let guidStr = "(guid '" + refKey + "')";

    var data = null;

    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true; // запрашивать базовую аутентификацию стандартными средствами браузера

    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === 4) {
            cb(this.responseText);
        }
    });

    xhr.open(method, backendHost + "/" + entity + guidStr + "?" + queryParamsString);

    xhr.send(data);


}

// update?

function odataDelete(backendHost, entity, data, cb) {
    // backendHost: http://172.16.161.103/app/odata/standard.odata
    // entity: объект базы данных 1с (Document_АнкетаАбитуриента, Catalog_ФизическиеЛица и т.д...)
    // создаём массив для работы с параметрами запроса

    let method = 'DELETE';
    let queryParams=[], queryParamsString;
    let guidStr = "(guid '" + data['Ref_Key'] + "')";

    // если параметры отсутствуют то хотябы добавляем параметр для работы в формате json
    queryParams.push('$format=json');
    queryParamsString = queryParams.join('&');

    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true; // запрашивать базовую аутентификацию стандартными средствами браузера

    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === 4) {
            cb();
        }
    });

    xhr.open(method, backendHost + "/" + entity + guidStr + "?" + queryParamsString);
    xhr.send(null);
}



