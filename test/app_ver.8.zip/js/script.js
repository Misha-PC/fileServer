let h = 'http://api1c.nntc.nnov.ru/app/odata/standard.odata';
let e = 'Document_АнкетаАбитуриента';

/**
 * Реализация функционала по асинхронной работе
 * с формой (запрет синхронной отправки с перезагрузкой страницы) - начало
 */

// функция-коллбэк. Вызывается при наступлении события отправки формы
function mainFormOnSubmit(evt) {
    // здесь evt -- это есть событие (submit)
    evt.preventDefault(); // отмена умолчального поведения формы (асинхронная отправка)

    // получаем состояние формы
    let formData = new FormData(document.forms['main-form']);

    // получаем действие пользователя из выпадающего списка
    let action = formData.get('action');

    // берём с формы все чекбоксы в переменную (массив) checkboxes
    let checkboxes = document.getElementsByName('select[]');

    // заводим переменную (массив) selected
    // для хранения в ней значений выбранных пользователем чекбоксов
    let selected = [];

    // проходим в цикле по всем элементам checkboxes
    for (var i = 0; i < checkboxes.length; i++) {

        if (checkboxes[i].checked) {
            // значения только выбранных чекбоксов добавляем в массив selected
            selected.push(checkboxes[i].value);
        }
    }

    // после обработки в цикле в selected получаем значения только выбранных
    // пользователем чекбоксов (для последующей печати или удаления, или еще чего-нибудь...)

    let markup, ii;

    function odataRetrieveCurrentCallback1(otvet) {
        let data = JSON.parse(otvet);
        markup += '<tr><td>' + (ii + 1) + '</td><td>' + data['Фамилия'] + '</td><td>' + data['Имя'] + '</td><td>' + data['Отчество'] + '</td></tr>'
        ii++;
        if (ii !== selected.length) {
            iter1();
        } else {
            markup += '</tbody></table>';
            document.getElementById('print-content').innerHTML = markup;
            enablePrintMode();
        }
    }


    function iter1() {
        let currentRefKey = selected[ii];
        odataRetrieve(h, 'GET', e, odataRetrieveCurrentCallback1, currentRefKey);
    }

    function odataRetrieveCurrentCallback2(otvet) {
        let data = JSON.parse(otvet);
        markup += '<li>' + data['Фамилия'] + ' ' + data['Имя'] + ' ' + data['Отчество'] + '</li>';
        ii++;
        if (ii !== selected.length) {
            iter2();
        } else {
            markup += '</ul>';
            document.getElementById('batch-delete-wrapper').innerHTML = markup;

            //btn-batch-delete

            function doBatchDeleteCallback(){

                function batchIterCallback(){
                    // это момент когда jj-я запись уже удалена
                    jj++;

                    if (jj !== deleteFormDataRows.length) {
                        batchIter();
                    } else {
                        // удаляемые записи закончились - закрывае диалог, обновляем таблицу
                        deleteBatchDialogCloseCallback();
                        updateTable();
                    }
                }

                let jj = 0;
                function batchIter() {
                    let currentKey = deleteFormDataRows[jj];
                    console.log('удаляем запись:', currentKey);
                    // ???????
                    // фиктивный вызов batchIterCallback();
                    batchIterCallback();
                }

                batchIter();
            }

            document.getElementById('btn-batch-delete')
                .addEventListener('click', doBatchDeleteCallback);

            deleteBatchDialogOpenCallback();
        }
    }


    function iter2() {
        let currentRefKey = selected[ii];
        odataRetrieve(h, 'GET', e, odataRetrieveCurrentCallback2, currentRefKey);
    }

    switch (action) {
        case 'print':
            // логика работы если пользователь выбрал печать
            markup = '<table border="1" align="center" cellspacing="1" cellpadding="2" width="100%"><thead>' +
                '<tr>' +
                '<th style="width: 40px;"><b>№</b></th>' +
                '<th>Фамилия</th>' +
                '<th>Имя</th>' +
                '<th>Отчество</th>' +
                '</tr>' +
                '</thead>' +
                '<tbody>';

            ii = 0;

            iter1();

            break;
        case 'delete':
            // логика работы если пользователь выбрал удаление
            //console.log('Удаляем...', selected);
            deleteFormDataRows = selected;
            markup = '<ul>';
            ii = 0;
            iter2();
            break;
        default:
            console.log('Пользователь ничего не выбрал')
    }

}

// отобрать форму на дереве DOM
let mainForm = document.getElementById('main-form');

mainForm.addEventListener('submit', mainFormOnSubmit);


/**
 * Реализация функционала по асинхронной работе
 * с формой (запрет синхронной отправки с перезагрузкой страницы) - конец
 */

function initTableBehavior() {
    /**
     * Реализация функционала по выбору всех строк в таблице - начало
     */

    // колбэк функция. вызывается на событие change элемента #checkbox-select-all

    function checkBoxAllCallback() {
        let checkboxes = document.getElementsByClassName('checkbox');

        for (var i = checkboxes.length - 1; i >= 0; i--) {
            checkboxes[i].checked = this.checked;
        }
    }

    // в переменной checkboxCheckAll содержится объект дерева DOM, отобранный по id=checkbox-select-all
    let checkboxCheckAll = document.getElementById('checkbox-select-all');

    // у объекта checkboxCheckAll прослушивается событие изменения состояния и на это событие вызывается
    // вышеописанный коллбэк
    checkboxCheckAll.addEventListener('change', checkBoxAllCallback);

    /**
     * Реализация функционала по выбору всех строк в таблице - конец
     */


    /**
     * Реализация функционала по клику в заголовки - начало
     */

    // колбэк функция. вызывается на событие click элементов .table-header-field
    function clickOnTableHeaderCallback(e) {
        // читаем значение свойства id тыкнутого заголовка таблицы
        sortField = e.target.getAttribute('id');
        // if(sortOrigin === 'desc') {
        // 	sortOrigin === 'asc';
        // } else {
        // 	sortOrigin === 'desc';
        // }
        sortOrigin = (sortOrigin === 'desc') ? 'asc' : 'desc';

        localStorage.setItem('sortField', sortField);
        localStorage.setItem('sortOrigin', sortOrigin);

        updateTable();
    }

    let tableHeaderSelectors = document.getElementsByClassName('table-header-field');
    // проходим в цикле по всем элементам tableHeaderSelectors
    for (var i = 0; i < tableHeaderSelectors.length; i++) {
        let each = tableHeaderSelectors[i];
        each.addEventListener('click', clickOnTableHeaderCallback);
    }

    /**
     * Реализация функционала по клику в заголовки - конец
     */

}

// функция возвращает один из трёх классов для отображения порядка сортировки в таблице в зависимости от вх. параметра
function getOrderClass(currentSortField) {

    if (sortField !== currentSortField) {
        return 'order-none';
    }

    if (sortOrigin === 'asc') {
        return 'order-down';
    }

    if (sortOrigin === 'desc') {
        return 'order-up';
    }
}

function updateTable() {


    let m = 'GET';


    let cb1 = function (otvet) {
        let data = JSON.parse(otvet);

        let markup = '';
        //markup += 'Debug: ' + sortField + ' --- ' + sortOrigin + '<hr>';
        markup += '<table border="1" align="center" cellspacing="1" cellpadding="2" width="100%"><thead>' +
            '<tr>' +
            '<td><input type="checkbox" id="checkbox-select-all" name="select-all"></td>' +
            '<td style="width: 40px;"><b>№</b></td>' +
            '<td><b class="table-header-field" id="Фамилия">Фамилия<span id="Фамилия" class="order ' + getOrderClass('Фамилия') + '">&nbsp;&nbsp;</span></b></td>' +
            '<td><b class="table-header-field" id="Имя">Имя<span id="Имя" class="order ' + getOrderClass('Имя') + '">&nbsp;&nbsp;</span></b></td>' +
            '<td><b class="table-header-field" id="Отчество">Отчество<span id="Отчество" class="order ' + getOrderClass('Отчество') + '">&nbsp;&nbsp;</span></b></td>' +
            '<td><button type="button" id="btn-add-open">Добавить</button></td>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';

        let rows = data.value;

        for (var i = 0; i < rows.length; i++) {
            let currentRow = rows[i];
            markup += '<tr>' +
                '<td><input type="checkbox" class="checkbox" value="' + currentRow['Ref_Key'] + '" name="select[]"></td>' +
                '<td>' + (i + skip + 1) + '</td>' +
                '<td>' + currentRow['Фамилия'] + '</td>' +
                '<td>' + currentRow['Имя'] + '</td>' +
                '<td>' + currentRow['Отчество'] + '</td>' +
                '<td>' +
                '    <button class="btn-edit-open" id="' + currentRow['Ref_Key'] + '" type="button" height="45px" type="image">&nbsp;</button>' +
                '    <button class="btn-delete-open" id="' + currentRow['Ref_Key'] + '" type="button" height="40px" type="image">&nbsp;</button>' +
                '</td>' +
                '</tr>';
        }

        markup += ' </tbody></table>';

        let tableWrapper = document.getElementById('table-wrapper');
        tableWrapper.innerHTML = markup;

        initTableBehavior();
        initDialogsBehavior();
    };

    let cb2 = function (otvet) {
        let data = JSON.parse(otvet);
        rowsCount = data;
        pagesCnt = Math.ceil(rowsCount / top1);
        curPageNum = (skip / top1) + 1;

        // отобрать на дереве DOM элементы интерфейса и положить туда curPageNum и pagesCnt
        let pagesCntWrapper = document.getElementById('pages-cnt');
        pagesCntWrapper.innerHTML = pagesCnt;

        let curPageNumWrapper = document.getElementById('cur-page-num');
        curPageNumWrapper.innerHTML = curPageNum;

    };

    let orderParam = '$orderby=' + sortField + ' ' + sortOrigin;

    let p = [
        '$select=Фамилия,Имя,Отчество,Ref_Key',
        '$top=' + top1,
        '$skip=' + skip,
        orderParam
    ];

    request(h, m, e, cb1, p);
    requestCount(h, m, e, cb2);

}

function enablePrintMode() {
    document.getElementById('ui').classList.remove('show');
    document.getElementById('ui').classList.add('hide');
    document.getElementById('print').classList.remove('hide');
    document.getElementById('print').classList.add('show');
}

function disablePrintMode() {
    document.getElementById('print').classList.remove('show');
    document.getElementById('print').classList.add('hide');
    document.getElementById('ui').classList.remove('hide');
    document.getElementById('ui').classList.add('show');
}

document
    .getElementById('btn-back')
    .addEventListener('click', function () {
        disablePrintMode()
    });

document
    .getElementById('btn-print')
    .addEventListener('click', function () {
        window.print()
    });

// логика после загрузки страницы

// инициализация прослушивания событий на кнопках постраничной навигации
//btn-backw
//btn-forw
let btnBackw = document.getElementById('btn-backw');

function btnBackwCallback() {

    if ((skip - top1) < 0) {
        skip = 0
    } else {
        skip = skip - top1;
    }
    localStorage.setItem('skip', skip);
    updateTable();
}

btnBackw.addEventListener('click', btnBackwCallback);

let btnForw = document.getElementById('btn-forw');

function btnForwCallback() {

    if ((skip + top1) >= rowsCount) {
        //skip = 0
    } else {
        skip = skip + top1;
    }

    localStorage.setItem('skip', skip);
    updateTable();
}

btnForw.addEventListener('click', btnForwCallback);


//1. проверяем значения переменных поля сортировки, порядка сортировки и кол-во пропущенных
// строк (для постраничной навигации) в лок. хранилище браузера
// если их нет, то создаём

let sortField, sortOrigin, top1, skip;

// общее количество записей. По-умолчанию ноль
// изменяется из функции updateTable
let rowsCount = 0;

// переменные для подсчёта текущей страницы и старниц всего
// изменяется из функции updateTable
let curPageNum = 0;
let pagesCnt = 0;


if (null === localStorage.getItem('sortField')) {
    // в лок. храинилще не существует ключа sortField. значит создаём
    sortField = 'Фамилия';
    localStorage.setItem('sortField', sortField);
} else {
    sortField = localStorage.getItem('sortField')
}

if (null === localStorage.getItem('sortOrigin')) {
    // в лок. храинилще не существует ключа sortOrigin. значит создаём
    sortOrigin = 'desc';
    localStorage.setItem('sortOrigin', sortOrigin);
} else {
    sortOrigin = localStorage.getItem('sortOrigin');
}

if (null === localStorage.getItem('top')) {
    // в лок. храинилще не существует ключа top. значит создаём
    top1 = 7;
    localStorage.setItem('top', top1);
} else {
    top1 = parseInt(localStorage.getItem('top'));
}

if (null === localStorage.getItem('skip')) {
    // в лок. храинилще не существует ключа skip. значит создаём
    skip = 0;
    localStorage.setItem('skip', skip);
} else {
    skip = parseInt(localStorage.getItem('skip'));
}

updateTable();